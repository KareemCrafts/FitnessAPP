package com.example.fitmate.models;

/**
 * Workout is a model class that represents a single workout.
 * It contains the name, description, and type of the workout.
 */
public class Workout {

    /**
     * An enum representing the different types of workouts.
     */
    public enum Type { STRENGTH, CARDIO, YOGA, LEG, FULL_BODY }

    // The name of the workout.
    private String name;
    // A detailed description of the workout.
    private String description;
    // The type of the workout.
    private Type type;

    /**
     * Constructor for the Workout class.
     * @param name The name of the workout.
     * @param description A detailed description of the workout.
     * @param type The type of the workout.
     */
    public Workout(String name, String description, Type type) {
        this.name = name;
        this.description = description;
        this.type = type;
    }

    /**
     * Returns the name of the workout.
     * @return The name of the workout.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the description of the workout.
     * @return The description of the workout.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Returns the type of the workout.
     * @return The type of the workout.
     */
    public Type getType() {
        return type;
    }
}
