package com.example.fitmate.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.fitmate.R;

import java.util.Locale;

public class StopwatchFragment extends Fragment {

    private TextView tvTimer;
    private Button btnStartStop, btnReset;
    private int seconds = 0;
    private boolean running;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_stopwatch, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvTimer = view.findViewById(R.id.tv_timer);
        btnStartStop = view.findViewById(R.id.btn_start_stop);
        btnReset = view.findViewById(R.id.btn_reset);
        ImageButton btnBack = view.findViewById(R.id.btn_back);

        btnStartStop.setOnClickListener(v -> {
            running = !running;
            btnStartStop.setText(running ? "Stop" : "Start");
        });

        btnReset.setOnClickListener(v -> {
            running = false;
            seconds = 0;
            updateTimerText();
            btnStartStop.setText("Start");
        });

        btnBack.setOnClickListener(v -> Navigation.findNavController(view).navigateUp());

        runTimer();
    }

    private void runTimer() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (running) {
                    seconds++;
                    updateTimerText();
                }
                handler.postDelayed(this, 1000);
            }
        });
    }

    private void updateTimerText() {
        int hours = seconds / 3600;
        int minutes = (seconds % 3600) / 60;
        int secs = seconds % 60;
        String time = String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, secs);
        tvTimer.setText(time);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        handler.removeCallbacksAndMessages(null);
    }
}
