package com.example.fitmate.utils;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * SharedPreferencesHelper is a utility class for managing SharedPreferences in the app.
 * It provides methods for saving and retrieving user data, such as login status and email.
 */
public class SharedPreferencesHelper {

    // The name of the SharedPreferences file.
    private static final String PREF_NAME = "FitMatePrefs";
    // Keys for storing data in SharedPreferences.
    private static final String KEY_EMAIL = "user_email";
    private static final String KEY_PASSWORD = "user_password";
    private static final String KEY_IS_LOGGED_IN = "is_logged_in";
    private static final String KEY_BMI_HISTORY = "bmi_history";

    /**
     * Returns an instance of SharedPreferences.
     * @param context The context of the calling activity or fragment.
     * @return An instance of SharedPreferences.
     */
    private static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    /**
     * Saves the user's email and password to SharedPreferences.
     * @param context The context of the calling activity or fragment.
     * @param email The user's email.
     * @param password The user's password.
     */
    public static void saveUser(Context context, String email, String password) {
        SharedPreferences.Editor editor = getPrefs(context).edit();
        editor.putString(KEY_EMAIL, email);
        editor.putString(KEY_PASSWORD, password);
        editor.apply();
    }

    /**
     * Saves the user's email to SharedPreferences.
     * @param context The context of the calling activity or fragment.
     * @param email The user's email.
     */
    public static void setEmail(Context context, String email) {
        SharedPreferences.Editor editor = getPrefs(context).edit();
        editor.putString(KEY_EMAIL, email);
        editor.apply();
    }

    /**
     * Validates the user's email and password against the stored values.
     * @param context The context of the calling activity or fragment.
     * @param email The user's email.
     * @param password The user's password.
     * @return true if the email and password are valid, false otherwise.
     */
    public static boolean validateUser(Context context, String email, String password) {
        String storedEmail = getPrefs(context).getString(KEY_EMAIL, null);
        String storedPassword = getPrefs(context).getString(KEY_PASSWORD, null);
        return email.equalsIgnoreCase(storedEmail) && password.equals(storedPassword);
    }

    /**
     * Returns the user's email from SharedPreferences.
     * @param context The context of the calling activity or fragment.
     * @return The user's email, or "N/A" if it is not found.
     */
    public static String getEmail(Context context) {
        return getPrefs(context).getString(KEY_EMAIL, "N/A");
    }

    /**
     * Sets the user's login status in SharedPreferences.
     * @param context The context of the calling activity or fragment.
     * @param isLoggedIn The user's login status.
     */
    public static void setLoggedIn(Context context, boolean isLoggedIn) {
        SharedPreferences.Editor editor = getPrefs(context).edit();
        editor.putBoolean(KEY_IS_LOGGED_IN, isLoggedIn);
        editor.apply();
    }

    /**
     * Returns the user's login status from SharedPreferences.
     * @param context The context of the calling activity or fragment.
     * @return true if the user is logged in, false otherwise.
     */
    public static boolean isLoggedIn(Context context) {
        return getPrefs(context).getBoolean(KEY_IS_LOGGED_IN, false);
    }

    /**
     * Saves the BMI history to SharedPreferences.
     * @param context The context of the calling activity or fragment.
     * @param bmiHistory The list of BMI results to save.
     */
    public static void saveBmiHistory(Context context, List<String> bmiHistory) {
        SharedPreferences.Editor editor = getPrefs(context).edit();
        Gson gson = new Gson();
        String json = gson.toJson(bmiHistory);
        editor.putString(KEY_BMI_HISTORY, json);
        editor.apply();
    }

    /**
     * Returns the BMI history from SharedPreferences.
     * @param context The context of the calling activity or fragment.
     * @return The list of BMI results, or an empty list if none is found.
     */
    public static List<String> getBmiHistory(Context context) {
        String json = getPrefs(context).getString(KEY_BMI_HISTORY, null);
        if (json == null) {
            return new ArrayList<>();
        }
        Gson gson = new Gson();
        Type type = new TypeToken<ArrayList<String>>() {}.getType();
        return gson.fromJson(json, type);
    }
}
