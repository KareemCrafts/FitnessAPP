package com.example.fitmate.fragments;

import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.fitmate.R;
import com.example.fitmate.utils.SharedPreferencesHelper;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginFragment extends Fragment {

    private FirebaseAuth mAuth;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mAuth = FirebaseAuth.getInstance();

        // --- Animation --- //
        ImageView logo = view.findViewById(R.id.iv_login_logo);
        Animation fadeIn = AnimationUtils.loadAnimation(getContext(), R.anim.fade_in);
        logo.startAnimation(fadeIn);

        // --- Navigation --- //
        NavController navController = Navigation.findNavController(view);

        EditText etEmail = view.findViewById(R.id.et_email);
        EditText etPassword = view.findViewById(R.id.et_password);
        Button btnLogin = view.findViewById(R.id.btn_login);
        Button btnGoToRegister = view.findViewById(R.id.btn_go_to_register);
        Button btnForgotPassword = view.findViewById(R.id.btn_forgot_password);

        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etEmail.setError("Valid email is required");
                return;
            }

            if (password.isEmpty()) {
                etPassword.setError("Password is required");
                return;
            }

            // Attempt online login
            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            if (user != null && user.isEmailVerified()) {
                                SharedPreferencesHelper.saveUser(requireContext(), email, password); // Save for offline use
                                SharedPreferencesHelper.setLoggedIn(requireContext(), true);
                                navController.navigate(R.id.action_loginFragment_to_homeFragment);
                            } else {
                                Toast.makeText(getContext(), "Please verify your email", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // If online login fails (e.g. no internet), try offline validation
                            if (SharedPreferencesHelper.validateUser(requireContext(), email, password)) {
                                SharedPreferencesHelper.setLoggedIn(requireContext(), true);
                                navController.navigate(R.id.action_loginFragment_to_homeFragment);
                                Toast.makeText(getContext(), "Logged in offline", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getContext(), "Authentication failed: Check internet or credentials", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
        });

        btnGoToRegister.setOnClickListener(v -> navController.navigate(R.id.action_loginFragment_to_registerFragment));
        
        btnForgotPassword.setOnClickListener(v -> navController.navigate(R.id.action_loginFragment_to_forgotPasswordFragment));
    }
}
