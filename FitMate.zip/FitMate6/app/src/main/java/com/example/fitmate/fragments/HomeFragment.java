package com.example.fitmate.fragments;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import com.example.fitmate.R;
import com.example.fitmate.activities.BMICalculatorActivity;
import com.example.fitmate.activities.MotivationActivity;
import com.example.fitmate.activities.WaterTrackerActivity;
import com.example.fitmate.utils.NotificationWorker;
import com.google.android.material.card.MaterialCardView;

public class HomeFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Request notification permission for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        NavController navController = Navigation.findNavController(view);

        MaterialCardView cardWorkouts = view.findViewById(R.id.card_workouts);
        MaterialCardView cardMotivation = view.findViewById(R.id.card_motivation);
        MaterialCardView cardTrackFitness = view.findViewById(R.id.card_track_fitness);
        MaterialCardView cardBmi = view.findViewById(R.id.card_bmi_calculator);
        MaterialCardView cardWater = view.findViewById(R.id.card_water_tracker);
        MaterialCardView cardProfile = view.findViewById(R.id.card_profile);
        MaterialCardView cardTimer = view.findViewById(R.id.card_timer);
        MaterialCardView cardGymLocator = view.findViewById(R.id.card_gym_locator);
        ImageButton btnSettings = view.findViewById(R.id.btn_settings);

        cardWorkouts.setOnClickListener(v -> navController.navigate(R.id.action_homeFragment_to_workoutsFragment));
        cardMotivation.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), MotivationActivity.class);
            startActivity(intent);
        });
        cardTrackFitness.setOnClickListener(v -> navController.navigate(R.id.action_homeFragment_to_trackFitnessFragment));
        cardBmi.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), BMICalculatorActivity.class);
            startActivity(intent);
        });
        cardWater.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), WaterTrackerActivity.class);
            startActivity(intent);
        });
        cardProfile.setOnClickListener(v -> navController.navigate(R.id.action_homeFragment_to_profileFragment));
        cardTimer.setOnClickListener(v -> navController.navigate(R.id.action_homeFragment_to_stopwatchFragment));
        cardGymLocator.setOnClickListener(v -> navController.navigate(R.id.action_homeFragment_to_gymLocatorFragment));
        btnSettings.setOnClickListener(v -> navController.navigate(R.id.action_homeFragment_to_settingsFragment));

        scheduleNotification();
    }

    private void scheduleNotification() {
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();

        OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                .setConstraints(constraints)
                .build();

        WorkManager.getInstance(requireContext()).enqueue(workRequest);
    }
}
