package com.example.fitmate.fragments;

import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.fitmate.R;
import com.example.fitmate.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterFragment extends Fragment {

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_register, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        NavController navController = Navigation.findNavController(view);

        EditText etUsername = view.findViewById(R.id.et_username_register);
        EditText etEmail = view.findViewById(R.id.et_email_register);
        EditText etPassword = view.findViewById(R.id.et_password_register);
        RadioGroup rgGender = view.findViewById(R.id.rg_gender);
        Button btnRegister = view.findViewById(R.id.btn_register);
        Button btnGoToLogin = view.findViewById(R.id.btn_go_to_login);

        btnRegister.setOnClickListener(v -> {
            if (validateInput(etUsername, etEmail, etPassword, rgGender)) {
                String username = etUsername.getText().toString().trim();
                String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();
                int selectedId = rgGender.getCheckedRadioButtonId();
                RadioButton radioButton = view.findViewById(selectedId);
                String gender = radioButton.getText().toString();

                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                String userId = mAuth.getCurrentUser().getUid();
                                User user = new User(userId, username, email, gender);
                                mDatabase.child("users").child(userId).setValue(user);

                                mAuth.getCurrentUser().sendEmailVerification()
                                        .addOnCompleteListener(verificationTask -> {
                                            if (verificationTask.isSuccessful()) {
                                                Toast.makeText(getContext(), "Registration successful! Please verify your email.", Toast.LENGTH_LONG).show();
                                                navController.navigate(R.id.action_registerFragment_to_loginFragment);
                                            }
                                        });
                            } else {
                                Toast.makeText(getContext(), "Authentication failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        btnGoToLogin.setOnClickListener(v -> navController.navigate(R.id.action_registerFragment_to_loginFragment));
    }

    private boolean validateInput(EditText etUsername, EditText etEmail, EditText etPassword, RadioGroup rgGender) {
        String username = etUsername.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (username.isEmpty()) {
            etUsername.setError("Username is required");
            return false;
        }

        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Valid email is required");
            return false;
        }

        if (password.isEmpty() || password.length() < 6) {
            etPassword.setError("Password must be at least 6 characters");
            return false;
        }

        if (rgGender.getCheckedRadioButtonId() == -1) {
            Toast.makeText(getContext(), "Please select a gender", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}
