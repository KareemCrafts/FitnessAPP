package com.example.fitmate.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import com.example.fitmate.R;
import com.google.android.material.switchmaterial.SwitchMaterial;

/**
 * SettingsFragment provides the user with various settings to customize their app experience.
 * This includes a dark mode toggle and other placeholder settings.
 */
public class SettingsFragment extends Fragment {

    // Constants for SharedPreferences.
    private static final String THEME_PREF = "ThemePref";
    private static final String IS_DARK_MODE = "isDarkMode";

    /**
     * Called to have the fragment instantiate its user interface view.
     * @param inflater The LayoutInflater object that can be used to inflate any views in the fragment.
     * @param container If non-null, this is the parent view that the fragment's UI should be attached to.
     * @param savedInstanceState If non-null, this fragment is being re-constructed from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment.
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    /**
     * Called immediately after onCreateView(LayoutInflater, ViewGroup, Bundle) has returned, but before any saved state has been restored in to the view.
     * @param view The View returned by onCreateView(LayoutInflater, ViewGroup, Bundle).
     * @param savedInstanceState If non-null, this fragment is being re-constructed from a previous saved state as given here.
     */
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize the views.
        SwitchMaterial themeSwitch = view.findViewById(R.id.theme_switch_settings);
        SwitchMaterial notificationSwitch = view.findViewById(R.id.notifications_switch);
        ImageButton btnBack = view.findViewById(R.id.btn_back_from_settings);
        NavController navController = Navigation.findNavController(view);

        // Get the SharedPreferences for the theme.
        SharedPreferences themePrefs = requireActivity().getSharedPreferences(THEME_PREF, Context.MODE_PRIVATE);
        // Get the current dark mode state, defaulting to true.
        boolean isDarkMode = themePrefs.getBoolean(IS_DARK_MODE, true);

        // Set the switch to the current state.
        themeSwitch.setChecked(isDarkMode);

        // Set a listener for the theme switch.
        themeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Save the new theme state.
            themePrefs.edit().putBoolean(IS_DARK_MODE, isChecked).apply();
            // Apply the new theme.
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            }
        });

        // Set a listener for the notification switch.
        notificationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Handle notification preference change.
            Toast.makeText(getContext(), "Notifications " + (isChecked ? "enabled" : "disabled"), Toast.LENGTH_SHORT).show();
        });

        // Set a listener for the back button.
        btnBack.setOnClickListener(v -> navController.navigateUp());

        // Set listeners for the placeholder settings.
        view.findViewById(R.id.tv_unit_system).setOnClickListener(v -> Toast.makeText(getContext(), "Unit System Clicked", Toast.LENGTH_SHORT).show());
        view.findViewById(R.id.tv_help).setOnClickListener(v -> Toast.makeText(getContext(), "Help Clicked", Toast.LENGTH_SHORT).show());
        view.findViewById(R.id.tv_about).setOnClickListener(v -> Toast.makeText(getContext(), "About Clicked", Toast.LENGTH_SHORT).show());
    }
}
