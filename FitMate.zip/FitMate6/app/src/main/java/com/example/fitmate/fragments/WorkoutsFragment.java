package com.example.fitmate.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.fitmate.R;
import com.example.fitmate.adapters.WorkoutAdapter;
import com.example.fitmate.models.Workout;

import java.util.ArrayList;
import java.util.List;

/**
 * WorkoutsFragment displays a list of available workouts.
 * The workouts are displayed in a grid layout, and clicking on a workout navigates to the WorkoutDetailsActivity.
 */
public class WorkoutsFragment extends Fragment {

    /**
     * Called to have the fragment instantiate its user interface view.
     * @param inflater The LayoutInflater object that can be used to inflate any views in the fragment.
     * @param container If non-null, this is the parent view that the fragment's UI should be attached to.
     * @param savedInstanceState If non-null, this fragment is being re-constructed from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment.
        return inflater.inflate(R.layout.fragment_workouts, container, false);
    }

    /**
     * Called immediately after onCreateView(LayoutInflater, ViewGroup, Bundle) has returned, but before any saved state has been restored in to the view.
     * @param view The View returned by onCreateView(LayoutInflater, ViewGroup, Bundle).
     * @param savedInstanceState If non-null, this fragment is being re-constructed from a previous saved state as given here.
     */
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize the views.
        RecyclerView rvWorkouts = view.findViewById(R.id.rv_workouts);
        ImageButton btnBack = view.findViewById(R.id.btn_back_from_workouts);

        // Get the list of workouts.
        List<Workout> workouts = getWorkouts();
        // Create a new WorkoutAdapter and set it to the RecyclerView.
        WorkoutAdapter adapter = new WorkoutAdapter(workouts, getContext());
        rvWorkouts.setAdapter(adapter);
        // Set the layout manager for the RecyclerView to a GridLayoutManager with 2 columns.
        rvWorkouts.setLayoutManager(new GridLayoutManager(requireContext(), 2));

        // Set a click listener for the back button.
        btnBack.setOnClickListener(v -> {
            NavController navController = Navigation.findNavController(v);
            navController.navigateUp();
        });
    }

    /**
     * Returns a list of sample workouts.
     * @return A list of Workout objects.
     */
    private List<Workout> getWorkouts() {
        List<Workout> workouts = new ArrayList<>();
        workouts.add(new Workout("Full Body Workout",
                "This full-body routine trains all major muscle groups in one session. It improves overall strength, endurance, and calorie burn.\n\nExercises:\nPush-ups – 3 sets x 10–12 reps\nBodyweight Squats – 3 sets x 15 reps\nPlank – 3 rounds x 30 seconds\nDumbbell Rows (or water bottle alternative) – 3 sets x 12 reps\nGlute Bridge – 3 sets x 12 reps\nMountain Climbers – 3 rounds x 20 seconds",
                Workout.Type.FULL_BODY));

        workouts.add(new Workout("Cardio Workout",
                "A fast-paced cardio session designed to burn calories, increase stamina, and improve heart health.\n\nExercises:\nJumping Jacks – 3 rounds x 45 seconds\nHigh Knees – 3 rounds x 40 seconds\nBurpees – 3 sets x 10 reps\nFast Jog in Place – 3 rounds x 1 minute\nButt Kicks – 3 rounds x 40 seconds",
                Workout.Type.CARDIO));

        workouts.add(new Workout("Morning Yoga Routine",
                "A gentle and energizing morning yoga flow that improves flexibility, reduces stiffness, and prepares the mind and body for the day.\n\nPoses:\nCat-Cow – 10 slow reps\nDownward Dog – hold 30 seconds\nChild’s Pose – hold 30 seconds\nCobra Stretch – hold 20 seconds\nWarrior I – hold 20 seconds each side\nForward Fold – hold 30 seconds",
                Workout.Type.YOGA));

        workouts.add(new Workout("Leg Day Workout",
                "Leg Day focuses on strengthening the entire lower body, targeting the quads, hamstrings, glutes, and calves. This routine builds power, stability, and endurance.\n\nExercises:\nSquats – 3 sets x 12 reps\nLunges – 3 sets x 10 reps each leg\nLeg Press (or bodyweight alternative) – 3 sets x 12 reps\nHamstring Curls – 3 sets x 12 reps\nCalf Raises – 3 sets x 15 reps\nGlute Bridge – 3 sets x 12 reps",
                Workout.Type.LEG));

        workouts.add(new Workout("Core Burner",
                "A concentrated workout to strengthen your abs and obliques.\n\nExercises:\nCrunches – 3 sets x 20 reps\nLeg Raises – 3 sets x 15 reps\nRussian Twists – 3 sets x 20 reps (10 per side)",
                Workout.Type.STRENGTH));

        workouts.add(new Workout("Upper Body Blast",
                "A workout to build strength and definition in your chest, back, shoulders, and arms.\n\nExercises:\nPush-ups – 3 sets x 15 reps\nBicep Curls – 3 sets x 12 reps per arm\nTricep Dips – 3 sets x 12 reps",
                Workout.Type.STRENGTH));

        return workouts;
    }
}
