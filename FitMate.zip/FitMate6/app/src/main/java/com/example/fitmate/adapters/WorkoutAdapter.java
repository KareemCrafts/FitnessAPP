package com.example.fitmate.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.fitmate.R;
import com.example.fitmate.activities.WorkoutDetailsActivity;
import com.example.fitmate.models.Workout;
import java.util.List;

/**
 * WorkoutAdapter is a custom RecyclerView adapter for displaying a list of workouts.
 * Each workout is displayed as a card with an image and a name.
 */
public class WorkoutAdapter extends RecyclerView.Adapter<WorkoutAdapter.WorkoutViewHolder> {

    // The list of workouts to be displayed.
    private List<Workout> workouts;
    // The context of the calling activity or fragment.
    private Context context;

    /**
     * Constructor for the WorkoutAdapter.
     * @param workouts The list of workouts to display.
     * @param context The context of the calling activity or fragment.
     */
    public WorkoutAdapter(List<Workout> workouts, Context context) {
        this.workouts = workouts;
        this.context = context;
    }

    /**
     * Called when RecyclerView needs a new {@link WorkoutViewHolder} of the given type to represent an item.
     * @param parent The ViewGroup into which the new View will be added after it is bound to an adapter position.
     * @param viewType The view type of the new View.
     * @return A new WorkoutViewHolder that holds a View of the given view type.
     */
    @NonNull
    @Override
    public WorkoutViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for a single workout item.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_workout, parent, false);
        return new WorkoutViewHolder(view);
    }

    /**
     * Called by RecyclerView to display the data at the specified position.
     * @param holder The WorkoutViewHolder which should be updated to represent the contents of the item at the given position in the data set.
     * @param position The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(@NonNull WorkoutViewHolder holder, int position) {
        // Get the workout at the current position.
        Workout workout = workouts.get(position);
        // Set the workout name.
        holder.tvWorkoutName.setText(workout.getName());

        // Set the workout image based on the workout type.
        int imageRes;
        switch (workout.getType()) {
            case LEG:
            case STRENGTH:
                imageRes = R.drawable.ic_launcher_foreground;
                break;
            case FULL_BODY:
                imageRes = R.drawable.ic_workout_full_body;
                break;
            case CARDIO:
                imageRes = R.drawable.ic_workout_cardio;
                break;
            case YOGA:
                imageRes = R.drawable.ic_workout_yoga;
                break;
            default:
                imageRes = R.drawable.ic_workout_strength;
                break;
        }
        holder.ivWorkoutImage.setImageResource(imageRes);

        // Set a click listener on the workout item to open the WorkoutDetailsActivity.
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, WorkoutDetailsActivity.class);
            intent.putExtra("workout_name", workout.getName());
            intent.putExtra("workout_image", imageRes);
            intent.putExtra("workout_description", workout.getDescription());
            context.startActivity(intent);
        });
    }

    /**
     * Returns the total number of items in the data set held by the adapter.
     * @return The total number of items in this adapter.
     */
    @Override
    public int getItemCount() {
        return workouts.size();
    }

    /**
     * A ViewHolder describes an item view and metadata about its place within the RecyclerView.
     */
    static class WorkoutViewHolder extends RecyclerView.ViewHolder {
        ImageView ivWorkoutImage;
        TextView tvWorkoutName;

        public WorkoutViewHolder(@NonNull View itemView) {
            super(itemView);
            ivWorkoutImage = itemView.findViewById(R.id.iv_workout_image);
            tvWorkoutName = itemView.findViewById(R.id.tv_workout_name);
        }
    }
}
