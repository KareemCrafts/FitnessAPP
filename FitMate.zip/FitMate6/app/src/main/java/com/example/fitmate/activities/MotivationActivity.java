package com.example.fitmate.activities;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.example.fitmate.R;
import java.util.Random;

/**
 * MotivationActivity displays motivational quotes to the user.
 * It features a button to show a new random quote.
 */
public class MotivationActivity extends AppCompatActivity {

    // The TextView that displays the current quote.
    private TextView tvQuote;
    // An array of motivational quotes.
    private final String[] quotes = {
        "The only bad workout is the one that didn't happen.",
        "Believe you can and you're halfway there.",
        "Push yourself because no one else is going to do it for you.",
        "Success isn't always about greatness. It's about consistency. Consistent hard work gains success. Greatness will come.",
        "The pain you feel today will be the strength you feel tomorrow.",
        "Your body can stand almost anything. It's your mind that you have to convince.",
        "Don't limit your challenges. Challenge your limits.",
        "A one-hour workout is 4% of your day. No excuses.",
        "The secret of getting ahead is getting started.",
        "You don't have to be extreme, just consistent.",
        "Sweat is just fat crying.",
        "Strive for progress, not perfection.",
        "The body achieves what the mind believes.",
        "It's not about being the best. It's about being better than you were yesterday.",
        "The gym is a marathon, not a sprint."
    };

    /**
     * Called when the activity is first created.
     * @param savedInstanceState If the activity is being re-initialized after previously being shut down then
     *                           this Bundle contains the data it most recently supplied in onSaveInstanceState(Bundle).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motivation);

        // Set up the toolbar and enable the back button.
        Toolbar toolbar = findViewById(R.id.toolbar_motivation);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Initialize the views.
        tvQuote = findViewById(R.id.tv_quote);
        Button btnNextQuote = findViewById(R.id.btn_next_quote);

        // Set a click listener on the "Next Quote" button to display a new random quote.
        btnNextQuote.setOnClickListener(v -> displayRandomQuote());
        
        // Display a random quote when the activity starts.
        displayRandomQuote();
    }

    /**
     * Selects a random quote from the quotes array and displays it in the TextView.
     */
    private void displayRandomQuote() {
        Random random = new Random();
        int index = random.nextInt(quotes.length);
        tvQuote.setText(quotes[index]);
    }

    /**
     * Handles action bar item clicks.
     * @param item The menu item that was selected.
     * @return boolean Return false to allow normal menu processing to proceed, true to consume it here.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle the back button click.
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
