package com.example.fitmate.activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import com.example.fitmate.R;
import com.google.firebase.FirebaseApp;

public class MainActivity extends AppCompatActivity {

    private static final String THEME_PREF = "ThemePref";
    private static final String IS_DARK_MODE = "isDarkMode";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Apply theme before setContentView
        SharedPreferences themePrefs = getSharedPreferences(THEME_PREF, Context.MODE_PRIVATE);
        boolean isDarkMode = themePrefs.getBoolean(IS_DARK_MODE, true); 
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        FirebaseApp.initializeApp(this);
        setContentView(R.layout.activity_main);
    }
}
