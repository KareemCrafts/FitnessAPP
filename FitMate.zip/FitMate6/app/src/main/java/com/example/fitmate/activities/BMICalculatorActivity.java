package com.example.fitmate.activities;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import com.example.fitmate.R;
import com.example.fitmate.utils.SharedPreferencesHelper;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class BMICalculatorActivity extends AppCompatActivity {

    private LinearLayout resultsContainer;
    private ProgressBar bmiProgressBar;
    private TextView tvBmiCategory, tvHealthTip, tvHealthyWeightRange, tvBmiHistory;
    private float currentBmi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi_calculator);

        Toolbar toolbar = findViewById(R.id.toolbar_bmi);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        EditText etHeight = findViewById(R.id.et_height);
        EditText etWeight = findViewById(R.id.et_weight);
        Button btnCalculate = findViewById(R.id.btn_calculate_bmi);
        Button btnSaveBmi = findViewById(R.id.btn_save_bmi);
        
        resultsContainer = findViewById(R.id.results_container);
        bmiProgressBar = findViewById(R.id.progress_bmi);
        tvBmiCategory = findViewById(R.id.tv_bmi_category);
        tvHealthTip = findViewById(R.id.tv_health_tip);
        tvHealthyWeightRange = findViewById(R.id.tv_healthy_weight_range);
        tvBmiHistory = findViewById(R.id.tv_bmi_history);

        btnCalculate.setOnClickListener(v -> {
            String heightStr = etHeight.getText().toString();
            String weightStr = etWeight.getText().toString();

            if (!heightStr.isEmpty() && !weightStr.isEmpty()) {
                float height = Float.parseFloat(heightStr) / 100;
                float weight = Float.parseFloat(weightStr);

                currentBmi = weight / (height * height);
                displayBMIResult(currentBmi, height);
                resultsContainer.setVisibility(View.VISIBLE);
            }
        });

        btnSaveBmi.setOnClickListener(v -> {
            saveBmiResult(currentBmi);
            displayBmiHistory();
        });

        displayBmiHistory();
    }

    private void displayBMIResult(float bmi, float height) {
        String bmiCategory;
        String healthTip;
        int backgroundColor;

        if (bmi < 18.5) {
            bmiCategory = "Underweight";
            healthTip = "Tip: Consider a balanced diet with more calories.";
            backgroundColor = R.drawable.bg_bmi_warning;
        } else if (bmi < 25) {
            bmiCategory = "Normal";
            healthTip = "Tip: Great job! Maintain a balanced diet and regular exercise.";
            backgroundColor = R.drawable.bg_bmi_normal;
        } else if (bmi < 30) {
            bmiCategory = "Overweight";
            healthTip = "Tip: A balanced diet and regular exercise can help.";
            backgroundColor = R.drawable.bg_bmi_warning;
        } else {
            bmiCategory = "Obese";
            healthTip = "Tip: A structured diet and exercise plan is recommended.";
            backgroundColor = R.drawable.bg_bmi_obese;
        }

        tvBmiCategory.setText(bmiCategory);
        tvHealthTip.setText(healthTip);
        tvBmiCategory.setBackground(ContextCompat.getDrawable(this, backgroundColor));
        bmiProgressBar.setProgress((int) bmi);

        // Calculate and display healthy weight range
        float lowerBound = 18.5f * (height * height);
        float upperBound = 24.9f * (height * height);
        String weightRange = String.format(Locale.getDefault(), "Healthy Weight Range: %.1f kg - %.1f kg", lowerBound, upperBound);
        tvHealthyWeightRange.setText(weightRange);
    }

    private void saveBmiResult(float bmi) {
        List<String> history = SharedPreferencesHelper.getBmiHistory(this);
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        history.add(0, String.format(Locale.getDefault(), "%.1f on %s", bmi, date));
        
        // Keep only the last 3 results
        if (history.size() > 3) {
            history = history.subList(0, 3);
        }
        
        SharedPreferencesHelper.saveBmiHistory(this, history);
    }

    private void displayBmiHistory() {
        List<String> history = SharedPreferencesHelper.getBmiHistory(this);
        StringBuilder historyStr = new StringBuilder();
        for (String record : history) {
            historyStr.append(record).append("\n");
        }
        tvBmiHistory.setText(historyStr.toString());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
