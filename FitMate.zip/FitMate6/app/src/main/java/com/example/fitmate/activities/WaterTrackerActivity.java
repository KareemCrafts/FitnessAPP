package com.example.fitmate.activities;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.example.fitmate.R;

/**
 * WaterTrackerActivity allows users to track their daily water intake.
 * It features a progress bar to visualize progress towards a daily goal, and buttons to add water and set a new goal.
 */
public class WaterTrackerActivity extends AppCompatActivity {

    // The current amount of water consumed by the user.
    private int waterIntake = 0;
    // The user's daily water intake goal, in milliliters.
    private int dailyGoal = 2000; // Default goal is 2000 ml

    /**
     * Called when the activity is first created.
     * @param savedInstanceState If the activity is being re-initialized after previously being shut down then
     *                           this Bundle contains the data it most recently supplied in onSaveInstanceState(Bundle).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_water_tracker);

        // Set up the toolbar and enable the back button.
        Toolbar toolbar = findViewById(R.id.toolbar_water);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Initialize the views.
        ProgressBar progressBar = findViewById(R.id.progress_bar_water);
        TextView tvIntake = findViewById(R.id.tv_water_intake);
        Button btnAddWater = findViewById(R.id.btn_add_water);
        EditText etGoal = findViewById(R.id.et_water_goal);
        Button btnSetGoal = findViewById(R.id.btn_set_goal);

        // Set the maximum value of the progress bar to the daily goal.
        progressBar.setMax(dailyGoal);

        // Set a click listener on the "Add Water" button.
        btnAddWater.setOnClickListener(v -> {
            waterIntake += 250;
            progressBar.setProgress(waterIntake);
            updateIntakeText(tvIntake);
        });

        // Set a click listener on the "Set Goal" button.
        btnSetGoal.setOnClickListener(v -> {
            String goalStr = etGoal.getText().toString();
            if (!goalStr.isEmpty()) {
                dailyGoal = Integer.parseInt(goalStr);
                progressBar.setMax(dailyGoal);
                updateIntakeText(tvIntake);
            }
        });
    }

    /**
     * Updates the text view that displays the current water intake.
     * @param tvIntake The TextView to update.
     */
    private void updateIntakeText(TextView tvIntake) {
        tvIntake.setText(String.format("You drank %d / %d ml today", waterIntake, dailyGoal));
    }

    /**
     * Handles action bar item clicks.
     * @param item The menu item that was selected.
     * @return boolean Return false to allow normal menu processing to proceed, true to consume it here.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
