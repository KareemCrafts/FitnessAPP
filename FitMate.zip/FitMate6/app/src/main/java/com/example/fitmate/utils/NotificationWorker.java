package com.example.fitmate.utils;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.fitmate.R;

public class NotificationWorker extends Worker {

    public NotificationWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        showNotification("Welcome Back!", "Check out your fitness progress today.");
        return Result.success();
    }

    private void showNotification(String title, String message) {
        NotificationManager notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = "fitmate_high_importance_channel";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Set importance to HIGH for heads-up notification
            NotificationChannel channel = new NotificationChannel(channelId, "FitMate High Priority Notifications", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Channel for high priority fitness alerts");
            channel.enableLights(true);
            channel.enableVibration(true);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), channelId)
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(R.mipmap.ic_launcher)
                // Set priority to HIGH for heads-up notification on older Android versions
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL) // Sound, vibration, lights
                .setAutoCancel(true);

        if (notificationManager != null) {
            notificationManager.notify(2, builder.build());
        }
    }
}
