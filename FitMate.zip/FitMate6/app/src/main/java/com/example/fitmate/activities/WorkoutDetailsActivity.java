package com.example.fitmate.activities;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.example.fitmate.R;

/**
 * WorkoutDetailsActivity displays the details of a specific workout, including its name, an image, and a description.
 * It also features a button to start a countdown timer for the exercise.
 */
public class WorkoutDetailsActivity extends AppCompatActivity {

    /**
     * Called when the activity is first created.
     * @param savedInstanceState If the activity is being re-initialized after previously being shut down then
     *                           this Bundle contains the data it most recently supplied in onSaveInstanceState(Bundle).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_details);

        // Set up the toolbar and enable the back button.
        Toolbar toolbar = findViewById(R.id.toolbar_workout_details);
        setSupportActionBar(toolbar);

        // Get the data passed from the previous screen (WorkoutsFragment).
        String workoutName = getIntent().getStringExtra("workout_name");
        int workoutImage = getIntent().getIntExtra("workout_image", R.drawable.placeholder_workout);
        String workoutDescription = getIntent().getStringExtra("workout_description");

        // Set the title of the toolbar to the workout name and enable the back button.
        getSupportActionBar().setTitle(workoutName);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Initialize the views.
        ImageView ivImage = findViewById(R.id.iv_workout_detail_image);
        TextView tvName = findViewById(R.id.tv_workout_detail_name);
        TextView tvDescription = findViewById(R.id.tv_workout_detail_description);
        Button btnStart = findViewById(R.id.btn_start_exercise);
        TextView tvCountdown = findViewById(R.id.tv_countdown);

        // Set the workout details to the views.
        tvName.setText(workoutName);
        ivImage.setImageResource(workoutImage);
        tvDescription.setText(workoutDescription);

        // Set a click listener on the "Start Exercise" button to start a countdown timer.
        btnStart.setOnClickListener(v -> {
            new CountDownTimer(10000, 1000) {
                public void onTick(long millisUntilFinished) {
                    tvCountdown.setText(String.valueOf(millisUntilFinished / 1000));
                }

                public void onFinish() {
                    tvCountdown.setText("Done!");
                }
            }.start();
        });
    }

    /**
     * Handles action bar item clicks.
     * @param item The menu item that was selected.
     * @return boolean Return false to allow normal menu processing to proceed, true to consume it here.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle the back button click.
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
