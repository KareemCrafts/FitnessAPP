package com.example.fitmate.fragments;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.fitmate.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

/**
 * TrackFitnessFragment displays fitness tracking information, including a bar chart for weekly steps.
 */
public class TrackFitnessFragment extends Fragment {

    private TextView tvStepsToday;
    private TextView tvCaloriesBurned;
    private BarChart barChart;

    /**
     * Called to have the fragment instantiate its user interface view.
     * @param inflater The LayoutInflater object that can be used to inflate any views in the fragment.
     * @param container If non-null, this is the parent view that the fragment's UI should be attached to.
     * @param savedInstanceState If non-null, this fragment is being re-constructed from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment.
        return inflater.inflate(R.layout.fragment_track_fitness, container, false);
    }

    /**
     * Called immediately after onCreateView(LayoutInflater, ViewGroup, Bundle) has returned, but before any saved state has been restored in to the view.
     * @param view The View returned by onCreateView(LayoutInflater, ViewGroup, Bundle).
     * @param savedInstanceState If non-null, this fragment is being re-constructed from a previous saved state as given here.
     */
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // --- Initialize Views --- //
        tvStepsToday = view.findViewById(R.id.tv_steps_today);
        tvCaloriesBurned = view.findViewById(R.id.tv_calories_burned);
        barChart = view.findViewById(R.id.bar_chart);

        // --- Back Button --- //
        ImageButton btnBack = view.findViewById(R.id.btn_back_from_track);
        btnBack.setOnClickListener(v -> {
            NavController navController = Navigation.findNavController(v);
            navController.navigateUp();
        });

        // --- Log New Entry Button --- //
        Button btnLogEntry = view.findViewById(R.id.btn_log_entry);
        btnLogEntry.setOnClickListener(v -> {
            // Reset steps and calories to 0
            tvStepsToday.setText("0");
            tvCaloriesBurned.setText("0 kcal");
            
            // Update the chart with the new data
            setupBarChart(true); // Pass true to reset the chart
            
            Toast.makeText(getContext(), "Today's progress has been reset!", Toast.LENGTH_SHORT).show();
        });

        // --- Bar Chart --- //
        setupBarChart(false); // Initial setup
    }

    /**
     * Sets up the BarChart with sample data.
     * @param resetData If true, the chart will be reset to 0 for the current day.
     */
    private void setupBarChart(boolean resetData) {
        ArrayList<BarEntry> entries = new ArrayList<>();
        if (resetData) {
            entries.add(new BarEntry(0, 0)); // Reset today's steps
        } else {
            entries.add(new BarEntry(0, 8234));
        }
        entries.add(new BarEntry(1, 7560));
        entries.add(new BarEntry(2, 9210));
        entries.add(new BarEntry(3, 6780));
        entries.add(new BarEntry(4, 10120));
        entries.add(new BarEntry(5, 8900));
        entries.add(new BarEntry(6, 9500));

        BarDataSet dataSet = new BarDataSet(entries, "Weekly Steps");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(16f);

        BarData barData = new BarData(dataSet);
        barChart.setData(barData);
        barChart.getDescription().setEnabled(false);
        barChart.setFitBars(true);
        barChart.invalidate(); // Refresh the chart
        barChart.animateY(1000);
    }
}
